# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.10.0]

Split from `@8ux-co/eelzap` (formerly `@8ux-co/eelzap-api-sdk-ts`): the
codegen CLI is now its own dev-only package, so `@inquirer/prompts` and
`dotenv` no longer install on a site. The version continues the SDK's line.

### Changed

- The bin is `eelzap`, and codegen is the `eelzap codegen` command (alias
  `eelzap gen`); `eelzap codegen [generate] [options]` replaces
  `eelzap-codegen [generate] [options]` with the same flags, config files and
  interactive mode. `eelzap generate …` is short for `eelzap codegen generate …`.
- The programmatic API moved from `@8ux-co/eelzap-api-sdk-ts/codegen` to
  `@8ux-co/eelzap-cli/codegen` (`generateTypes`, `resolveCodegenConfig`,
  `DEFAULT_CODEGEN_CONFIG`, the config types).
- Generated files import their helper types from `@8ux-co/eelzap`, and the
  default header names `@8ux-co/eelzap-cli`.
- `eelzap --version` resolves the package through a symlinked bin.
- Field comments in generated files name the API's field types: a text field is
  `TEXT`, as the field routes accept it and as the delivery schema now
  publishes it (no longer `SHORT_TEXT`); codegen reads the schema's types as is.

### Fixed

- Interactive setup asks for the API key with a masked prompt (`*` per
  character): the key is no longer echoed to the terminal as it is typed.
- Required fields of a **document** are typed non-null, as a collection's
  already were, and a document's ENUM values are narrowed: codegen reads the
  schema routes (`…/fields`, `…/sections`), which say what the delivery list
  does not. A GALLERY is never `| null`, since delivery sends `[]` when empty.
- Fields come in the builder's order, sections included, instead of sorted by
  `order` alone, which interleaved the root with each section.
- The CLI reads `.env.local` and the Next.js files (`.env.development[.local]`,
  `.env.production[.local]` by `NODE_ENV`) with Next's precedence, not only
  `.env`. Variables already set still win. `--verbose` names the files read.
- With a `public_` key, which the schema routes refuse, codegen falls back to
  the delivery schema and prints a warning; `generateTypes` returns it in
  `warnings`.

### Carried over from the SDK

- Enum fields are emitted as `EnumValue & { value: 'a' | 'b' }`, the
  `{ value, label }` object the delivery API returns (SDK 0.9.0).
